// Learning C++ 
// Exercise 02_03
// Using Variables, by Eduardo Corpeño 

#include <iostream>

int main(){
    std::cout << "Hi There!" << std::endl;
    
    std::cout << std::endl << std::endl;
    return (0);
}
