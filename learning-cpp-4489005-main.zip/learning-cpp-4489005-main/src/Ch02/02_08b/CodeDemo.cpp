// Learning C++ 
// Exercise 02_08
// Arrays, by Eduardo Corpeño 

#include <iostream>

int main(){
    
    std::cout << std::endl << std::endl;
    return (0);
}
