// Learning C++ 
// Exercise 02_06
// Preprocessor directives, by Eduardo Corpeño 

#include <iostream>

int main(){
    
    std::cout << std::endl << std::endl;
    return (0);
}
