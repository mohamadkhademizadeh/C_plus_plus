// Learning C++ 
// Exercise 04_01
// If Statements, by Eduardo Corpeño 

#include <iostream>

int main(){
    
    std::cout << std::endl << std::endl;
    return (0);
}
