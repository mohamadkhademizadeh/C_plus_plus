// Learning C++ 
// Exercise 01_02
// Hello World, by Eduardo Corpeño 

#include <iostream>

int main(){
    std::cout << "Hi There!" << std::endl;

    std::cout << std::endl << std::endl;
    return (0);
}
