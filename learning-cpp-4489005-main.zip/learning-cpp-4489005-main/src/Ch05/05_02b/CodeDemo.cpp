// Learning C++ 
// Exercise 05_02
// Function Parameters, by Eduardo Corpeño 

#include <iostream>

int main(){
    int a = 9, b;
    // TODO: square
    std::cout << "a = " << a << ", b = " << b << std::endl;
    // TODO: swap
    std::cout << "a = " << a << ", b = " << b << std::endl;
    // TODO: swap
    std::cout << "a = " << a << ", b = " << b << std::endl;
    
    std::cout << std::endl << std::endl;
    return (0);
}
