// Complete Guide to C++ Programming Foundations
// Exercise 05_04
// While Loops, by Eduardo Corpeño 

#include <iostream>
#include <vector>

int main(){
    std::vector<int> playerScores = {12, 25, 31, 47, 58};
    
    std::vector<int>::iterator scorePtr = playerScores.begin();
    
    std::cout << std::endl << std::endl;
    return (0);
}
