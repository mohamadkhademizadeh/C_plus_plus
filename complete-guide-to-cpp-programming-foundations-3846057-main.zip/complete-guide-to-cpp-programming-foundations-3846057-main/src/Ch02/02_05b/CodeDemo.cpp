// Complete Guide to C++ Programming Foundations
// Exercise 02_05
// Using Variables, by Eduardo Corpeño 

#include <iostream>

int main(){
    
    std::cout << std::endl << std::endl;
    return 0;
}
