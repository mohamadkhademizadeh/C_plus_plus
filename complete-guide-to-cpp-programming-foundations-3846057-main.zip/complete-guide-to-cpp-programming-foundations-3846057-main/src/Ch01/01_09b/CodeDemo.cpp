// Complete Guide to C++ Programming Foundations
// Challenge 01_09
// Terminal Interaction, by Eduardo Corpeño 

#include <iostream>

int main(){
    std::cout << "Hi There!" << std::endl;

    std::cout << std::endl << std::endl;
    return 0;
}