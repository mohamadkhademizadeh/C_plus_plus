// Complete Guide to C++ Programming Foundations
// Exercise 07_02
// Data Members, by Eduardo Corpeño 

#include <iostream>
#include <vector>
#include <string>

int main(){
    
    std::cout << std::endl << std::endl;
    return 0;
}
