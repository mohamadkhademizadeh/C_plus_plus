// Complete Guide to C++ Programming Foundations
// Exercise 06_04
// Writing Functions, by Eduardo Corpeño 

#include <iostream>
#include <string>

int main(){
    std::string playerName = "Alex";
    int score = 75;

    std::cout << playerName << " scored " << score << " points." << std::endl;
    
    std::cout << std::endl << std::endl;
    return 0;
}
