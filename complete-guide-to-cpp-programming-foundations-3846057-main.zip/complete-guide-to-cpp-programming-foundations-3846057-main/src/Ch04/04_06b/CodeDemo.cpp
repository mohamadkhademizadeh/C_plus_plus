// Complete Guide to C++ Programming Foundations
// Exercise 04_06
// The Vector Class, by Eduardo Corpeño 

#include <iostream>
#include <string>

int main(){
    
    std::cout << std::endl << std::endl;
    return 0;
}
